<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) Amasty (https://www.amasty.com)
 * @package One Step Checkout Core for Magento 2
 */

namespace Amasty\CheckoutCore\Model;

class CustomFormatFlag
{
    /**
     * @var bool
     */
    public static $flag = true;
}
